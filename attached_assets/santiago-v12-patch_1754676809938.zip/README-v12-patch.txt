This is the Santiago v12 patch.
Apply by uploading contents into your existing Replit Next.js project.

Features:
- Deal Amount Estimator (Lead Engine)
- HubSpot import includes amount field
- Calendly webhook HMAC verification
